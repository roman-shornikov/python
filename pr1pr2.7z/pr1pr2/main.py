import math

print("Введите число")
a=int(input())
z1 = math.cos(a)+math.sin(a)+math.cos(3*a)+math.sin(3*a)
print(z1)
z2 = 2*math.sqrt(2)*math.cos(a)*math.sin(math.pi/4+2*a)
print(z2)