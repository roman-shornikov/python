# №2
# string = "123456789"
# print("Вывод символов при помощи положительных индексов ")
# c3 = string[2]
# print(c3)
# c5 = string[4]
# print(c5)
# c567 = string[4:7]
# print(c567)
# print("Вывод символов при помощи отрицательных индексов ")
# c23 = string[-7]
# print(c23)
# c25 = string[-5]
# print(c25)
# x = string[-5:-2]
# print(x)
# №3
#
# b = "кот"
# print(b)
# tt = b[2] + b[1] + b[0]
# print(tt)
#
#
# №4
# a = [1, 2, 3, 4, 5, 6, 7, 8, 5, 564, 456]
# print(a[0])
# print(a[-1])

#
# №5
# def sum_range(start,end):
#     sum=0
#     if end < start:
#         start, end = end, start
#     for a in range(start,end,1):
#         sum=sum+a
#     return sum
# start = int(input())
# end =int(input())
# print(sum_range(start,end))