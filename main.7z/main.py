str=input()
nush=str.split(' ')
count=int(len(nush))
shug=0
for i in range(0,int(count)):
    if nush[i].__contains__("у"):
        shug+=1
    if nush[i].__contains__("ё"):
        shug+=1
    if nush[i].__contains__("й"):
        shug+=1
    if nush[i].__contains__("ы"):
        shug+=1
    if nush[i].__contains__("э"):
        shug+=1
    if nush[i].__contains__("и"):
        shug+=1
    if nush[i].__contains__("ю"):
        shug+=1
print(shug)
print(count-shug)
